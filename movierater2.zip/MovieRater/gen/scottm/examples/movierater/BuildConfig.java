/** Automatically generated file. DO NOT MODIFY */
package scottm.examples.movierater;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}